# Secure Python Repo Template (CI + Pre-commit)

This template gives you:
- GitHub Actions CI on **Python 3.12 + 3.13**
- Runs on **Ubuntu + Windows** (parity with your laptop)
- Blocks unsafe `subprocess` patterns (non-literal commands, `shell=True`)
- Linting (Ruff), typing (mypy), tests (pytest), security (Bandit, Semgrep), secrets (detect-secrets)

## Quick start (Windows PowerShell)

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip
pip install -r requirements-dev.txt
pre-commit install
pre-commit run --all-files
pytest
```

## Quick start (Linux/macOS)

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
pip install -r requirements-dev.txt
pre-commit install
pre-commit run --all-files
pytest
```

## Subprocess rule (what will fail)

Allowed:
```python
import subprocess
subprocess.run(["git","status"], check=True)
```

Blocked:
```python
import subprocess
subprocess.run(f"rm -rf {path}", shell=True)
subprocess.run(user_input)
```

## Files you’ll edit most
- `.github/workflows/ci-secure-python.yml`
- `.pre-commit-config.yaml`
- `.semgrep/subprocess.yml`
- `pyproject.toml`
