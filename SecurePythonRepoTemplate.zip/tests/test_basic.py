from your_package import hello

def test_hello():
    assert hello() == 'hello'
