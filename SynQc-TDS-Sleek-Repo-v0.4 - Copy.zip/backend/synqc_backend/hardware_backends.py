from __future__ import annotations

import random
import time
import zlib
from abc import ABC, abstractmethod
from typing import Dict

from .config import settings
from .models import ExperimentPreset, KpiBundle, ExperimentStatus


class BaseBackend(ABC):
    """Abstract base class for SynQc hardware backends.

    Concrete subclasses implement the logic to translate a high-level preset + shot
    budget into real hardware calls (or simulations) and return KPIs.
    """

    id: str
    name: str
    kind: str

    def __init__(self, id: str, name: str, kind: str) -> None:
        self.id = id
        self.name = name
        self.kind = kind

    @abstractmethod
    def run_experiment(self, preset: ExperimentPreset, shot_budget: int) -> KpiBundle:
        """Run the requested preset and return a KpiBundle.

        Implementations MUST obey the provided shot_budget (or lower),
        and they SHOULD NOT exceed engine-level limits. Those limits are
        enforced separately in the SynQcEngine, but backends need to be
        well-behaved as well.
        """


class LocalSimulatorBackend(BaseBackend):
    """Simple local simulator backend.

    This is intentionally lightweight and self-contained: it generates
    plausible KPI values without talking to real quantum hardware. The
    structure, not the physics, is the focus here.

    Future versions can replace the random draws with calls into a
    true SynQc simulator.
    """

    def __init__(self) -> None:
        super().__init__(id="sim_local", name="Local simulator", kind="sim" )

    def run_experiment(self, preset: ExperimentPreset, shot_budget: int) -> KpiBundle:
        # Clamp shots to something reasonable in this demo backend
        shots_used = min(shot_budget, settings.max_shots_per_experiment)

        # Seed randomness with time + preset to provide variety but some continuity
        base_seed = int(time.time()) ^ hash(preset.value)
        rng = random.Random(base_seed)

        if preset is ExperimentPreset.HEALTH:
            fidelity = 0.94 + rng.random() * 0.04  # 0.94–0.98
            latency = 15.0 + rng.random() * 6.0
            backaction = 0.15 + rng.random() * 0.1
        elif preset is ExperimentPreset.LATENCY:
            fidelity = None
            latency = 10.0 + rng.random() * 15.0
            backaction = 0.1 + rng.random() * 0.1
        elif preset is ExperimentPreset.BACKEND_COMPARE:
            fidelity = 0.93 + rng.random() * 0.05
            latency = 18.0 + rng.random() * 10.0
            backaction = 0.2 + rng.random() * 0.1
        else:  # DPD_DEMO or unknown
            fidelity = 0.9 + rng.random() * 0.08
            latency = 12.0 + rng.random() * 8.0
            backaction = 0.1 + rng.random() * 0.1

        status: ExperimentStatus
        if fidelity is not None and fidelity < 0.9:
            status = ExperimentStatus.FAIL
        elif fidelity is not None and fidelity < 0.94:
            status = ExperimentStatus.WARN
        else:
            status = ExperimentStatus.OK

        return KpiBundle(
            fidelity=fidelity,
            latency_us=latency,
            backaction=backaction,
            shots_used=shots_used,
            shot_budget=shot_budget,
            status=status,
        )




class ConceptSimBackend(BaseBackend):
    """Simulated placeholder backend for UI wiring.

    IMPORTANT:
      - This does NOT call real QPUs or lab hardware.
      - It exists so the frontend can stay functional and consistent while we
        integrate real provider SDKs in a controlled way.
    """

    def __init__(
        self,
        *,
        id: str,
        name: str,
        kind: str,
        fidelity_base: float | None,
        fidelity_span: float,
        latency_base_us: float,
        latency_span_us: float,
        backaction_base: float,
        backaction_span: float,
    ) -> None:
        super().__init__(id=id, name=name, kind=kind)
        self._fidelity_base = fidelity_base
        self._fidelity_span = fidelity_span
        self._latency_base_us = latency_base_us
        self._latency_span_us = latency_span_us
        self._backaction_base = backaction_base
        self._backaction_span = backaction_span

    def _rng(self, preset: ExperimentPreset) -> random.Random:
        # Use a stable-ish seed: time changes provide variety, zlib keeps deterministic mixing.
        salt = zlib.adler32(f"{self.id}:{preset.value}".encode("utf-8"))
        seed = int(time.time()) ^ salt
        return random.Random(seed)

    def run_experiment(self, preset: ExperimentPreset, shot_budget: int) -> KpiBundle:
        shots_used = min(shot_budget, settings.max_shots_per_experiment)
        rng = self._rng(preset)

        # Latency always exists for these demos.
        latency_us = self._latency_base_us + rng.random() * self._latency_span_us

        # Backaction always exists in this simplified KPI model.
        backaction = self._backaction_base + rng.random() * self._backaction_span

        fidelity = None
        if preset is not ExperimentPreset.LATENCY and self._fidelity_base is not None:
            fidelity = self._fidelity_base + rng.random() * self._fidelity_span
            fidelity = max(0.0, min(1.0, fidelity))

        status: ExperimentStatus
        if fidelity is not None and fidelity < 0.90:
            status = ExperimentStatus.FAIL
        elif fidelity is not None and fidelity < 0.94:
            status = ExperimentStatus.WARN
        elif backaction > 0.35:
            status = ExperimentStatus.WARN
        else:
            status = ExperimentStatus.OK

        return KpiBundle(
            fidelity=fidelity,
            latency_us=latency_us,
            backaction=backaction,
            shots_used=shots_used,
            shot_budget=shot_budget,
            status=status,
        )

# Registry of backends
_BACKENDS: Dict[str, BaseBackend] = {
    "sim_local": LocalSimulatorBackend(),

    # Concept placeholders (simulated):
    "ibm_qpu": ConceptSimBackend(
        id="ibm_qpu",
        name="IBM QPU (concept)",
        kind="superconducting",
        fidelity_base=0.92,
        fidelity_span=0.05,
        latency_base_us=28.0,
        latency_span_us=45.0,
        backaction_base=0.18,
        backaction_span=0.20,
    ),
    "ionq_qpu": ConceptSimBackend(
        id="ionq_qpu",
        name="IonQ QPU (concept)",
        kind="trapped_ion",
        fidelity_base=0.93,
        fidelity_span=0.06,
        latency_base_us=120.0,
        latency_span_us=260.0,
        backaction_base=0.10,
        backaction_span=0.18,
    ),
    "lab_fpga": ConceptSimBackend(
        id="lab_fpga",
        name="Lab FPGA rig (concept)",
        kind="fpga_lab",
        fidelity_base=None,      # Not meaningful for a classical rig in this toy KPI model
        fidelity_span=0.0,
        latency_base_us=2.0,
        latency_span_us=8.0,
        backaction_base=0.01,
        backaction_span=0.05,
    ),
}


def get_backend(target_id: str) -> BaseBackend:
    """Return a backend instance for the given target id.

    Raises KeyError if the backend is not known. The engine will catch this
    and translate to a user-visible error.
    """
    if target_id not in _BACKENDS:
        raise KeyError(f"Unknown hardware_target '{target_id}'")
    return _BACKENDS[target_id]


def list_backends() -> Dict[str, BaseBackend]:
    """Return the current backend registry (id -> backend)."""
    return dict(_BACKENDS)
